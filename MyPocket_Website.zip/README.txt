MyPocket web app. Upload this ZIP to a static hosting service such as Netlify Drop.
After deployment, open the HTTPS URL in Safari and use Share > Add to Home Screen.
Access code: 654321. Data is stored locally in the browser and the code is only a simple screen lock.
